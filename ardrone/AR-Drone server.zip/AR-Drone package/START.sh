#!/bin/sh
cd ./DATA/ardrone-webflight
./node app.js