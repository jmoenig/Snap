#!/bin/sh
cd ./DATA/ardrone-webflight
chmod +x ./node
./node app.js