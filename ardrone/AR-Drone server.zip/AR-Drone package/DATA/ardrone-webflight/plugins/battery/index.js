function battery(name, deps) {
    // Nothing special on the backend for now    
};

module.exports = battery;
