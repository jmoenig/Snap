function hud(name, deps) {
    // Nothing special on the backend for now    
};

module.exports = hud;
