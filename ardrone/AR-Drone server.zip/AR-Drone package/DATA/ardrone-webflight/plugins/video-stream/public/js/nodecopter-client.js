/* this is a dummy file that is replaced with dist/nodecopter-client.js
 * from the dronestream module by express.
 */
